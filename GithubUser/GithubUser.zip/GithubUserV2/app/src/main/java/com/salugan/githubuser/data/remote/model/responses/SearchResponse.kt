package com.salugan.githubuser.data.remote.model.responses

import com.google.gson.annotations.SerializedName
import com.salugan.githubuser.data.remote.model.User

data class SearchResponse(

	@field:SerializedName("total_count")
	val totalCount: Int? = null,

	@field:SerializedName("incomplete_results")
	val incompleteResults: Boolean? = null,

	@field:SerializedName("items")
	val users: List<User>? = null
)
