package com.salugan.githubuser.ui.fragments

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.ViewModel
import com.salugan.githubuser.data.Result
import com.salugan.githubuser.data.UserRepository
import com.salugan.githubuser.data.remote.model.User

class FollowViewModel(private val userRepository: UserRepository) : ViewModel() {

    private val followers = MediatorLiveData<Result<List<User>>>()

    private val following = MediatorLiveData<Result<List<User>>>()

    private var username: String? = null

    fun getFollowers(username: String): LiveData<Result<List<User>>> {
        if (this.username == null) {
            this.username = username
            val source = userRepository.getFollowers(username)
            followers.addSource(source) { result ->
                followers.value = result
            }
        }
        return followers
    }

    fun getFollowing(username: String): LiveData<Result<List<User>>> {
        if (this.username == null) {
            this.username = username
            val source = userRepository.getFollowing(username)
            following.addSource(source) { result ->
                following.value = result
            }
        }
        return following
    }
}