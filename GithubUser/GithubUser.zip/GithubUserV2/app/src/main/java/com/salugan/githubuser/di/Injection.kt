package com.salugan.githubuser.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import com.salugan.githubuser.data.UserRepository
import com.salugan.githubuser.data.local.room.FavoriteRoomDb
import com.salugan.githubuser.data.local.setting.SettingPreferences
import com.salugan.githubuser.data.remote.retrofit.ApiConfig

object Injection {
    fun provideRepository(context: Context): UserRepository {
        val apiService = ApiConfig.getApiService()
        val database = FavoriteRoomDb.getDatabase(context)
        val favoriteUserDao = database.favoriteUserDao()
        return UserRepository.getInstance(apiService, favoriteUserDao)
    }

    fun providePreferences(datastore: DataStore<Preferences>): SettingPreferences {
        return SettingPreferences.getInstance(datastore)
    }
}