package com.salugan.githubuser.data.remote.retrofit

import com.salugan.githubuser.data.remote.model.User
import com.salugan.githubuser.data.remote.model.responses.DetailUserResponse
import com.salugan.githubuser.data.remote.model.responses.SearchResponse
import retrofit2.http.*

interface ApiService {
    @GET("search/users")
    suspend fun getListUsers(
        @Query("q") username: String
    ) : SearchResponse

    @GET("users/{username}")
    suspend fun getDetailUser(
        @Path("username") username: String
    ) : DetailUserResponse

    @GET("users/{username}/followers")
    suspend fun getFollowers(
        @Path("username") username: String
    ): List<User>

    @GET("users/{username}/following")
    suspend fun getFollowing(
        @Path("username") username: String
    ): List<User>
}