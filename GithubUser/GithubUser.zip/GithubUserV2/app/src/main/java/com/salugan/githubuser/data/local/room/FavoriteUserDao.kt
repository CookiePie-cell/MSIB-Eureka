package com.salugan.githubuser.data.local.room

import androidx.lifecycle.LiveData
import androidx.room.*
import com.salugan.githubuser.data.local.entities.FavoriteUserEntity

@Dao
interface FavoriteUserDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(user: FavoriteUserEntity)

    @Delete
    suspend fun delete(user: FavoriteUserEntity)

    @Query("SELECT * FROM favorite_users")
    fun getFavoriteUsers(): LiveData<List<FavoriteUserEntity>>

    @Query("SELECT * FROM favorite_users WHERE username = :username")
    fun getFavoriteUserByUsername(username: String): LiveData<FavoriteUserEntity>
}