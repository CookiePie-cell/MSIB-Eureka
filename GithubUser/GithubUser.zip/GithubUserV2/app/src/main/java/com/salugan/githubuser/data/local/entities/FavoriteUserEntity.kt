package com.salugan.githubuser.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorite_users")
data class FavoriteUserEntity(
    @PrimaryKey(autoGenerate = false)
    val username: String = "",
    val avatarUrl: String? = null,
)
