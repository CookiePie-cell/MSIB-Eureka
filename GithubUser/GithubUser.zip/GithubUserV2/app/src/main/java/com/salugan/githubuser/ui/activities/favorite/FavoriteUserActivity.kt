package com.salugan.githubuser.ui.activities.favorite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.salugan.githubuser.R
import com.salugan.githubuser.adapters.ListUserAdapter
import com.salugan.githubuser.data.local.entities.FavoriteUserEntity
import com.salugan.githubuser.data.remote.model.User
import com.salugan.githubuser.databinding.ActivityFavoriteUserBinding
import com.salugan.githubuser.ui.ViewModelFactory

class FavoriteUserActivity : AppCompatActivity() {

    private lateinit var activityFavoriteUserBinding: ActivityFavoriteUserBinding

    private val favoriteViewModel by viewModels<FavoriteViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityFavoriteUserBinding = ActivityFavoriteUserBinding.inflate(layoutInflater)
        setContentView(activityFavoriteUserBinding.root)

        supportActionBar?.title = "Favorites"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val layoutManager = LinearLayoutManager(this)
        activityFavoriteUserBinding.rvUsers.layoutManager = layoutManager

        favoriteViewModel.getFavoriteUsers().observe(this) { users ->
            showLoading(true)
            checkVisibility(users)
        }

    }

    private fun checkVisibility(users: List<FavoriteUserEntity>) {
        if (users.isEmpty()) {
            showLoading(false)
            activityFavoriteUserBinding.rvUsers.visibility = View.GONE
            activityFavoriteUserBinding.emptyMessage.text = getString(R.string.no_favorite)
            activityFavoriteUserBinding.emptyMessage.visibility = View.VISIBLE
        } else {
            showLoading(false)
            activityFavoriteUserBinding.rvUsers.visibility = View.VISIBLE
            activityFavoriteUserBinding.emptyMessage.visibility = View.INVISIBLE
            setListUsers(users)
        }
    }

    private fun setListUsers(users: List<FavoriteUserEntity>) {
        val listUsers = users.map {
            User(login = it.username, avatarUrl = it.avatarUrl)
        }
        val adapter = ListUserAdapter(listUsers)
        activityFavoriteUserBinding.rvUsers.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            activityFavoriteUserBinding.progressBar.visibility = View.VISIBLE
        } else {
            activityFavoriteUserBinding.progressBar.visibility = View.GONE
        }
    }
}