package com.salugan.githubuser.ui.activities.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData

import com.salugan.githubuser.data.UserRepository
import com.salugan.githubuser.data.remote.model.User
import com.salugan.githubuser.data.Result
import com.salugan.githubuser.data.local.setting.SettingPreferences


class MainViewModel(private val userRepository: UserRepository, private val pref: SettingPreferences) : ViewModel() {

    private val searchResult = MediatorLiveData<Result<List<User>>>()

    var username: String? = null

    companion object {
        private const val INIT_USER = "torvalds"
    }

    init {
        findUsers(INIT_USER)
    }

    fun findUsers(username: String): LiveData<Result<List<User>>> {
        if (this.username == null) {
            this.username = username
            val source = userRepository.findUser(username)
            searchResult.addSource(source) { result ->
                searchResult.value = result
            }
        }
        return searchResult
    }

    fun getThemeSettings(): LiveData<Boolean> {
        return pref.getThemeSetting().asLiveData()
    }
}