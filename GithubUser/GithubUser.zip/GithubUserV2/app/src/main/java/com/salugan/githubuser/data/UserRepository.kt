package com.salugan.githubuser.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import com.salugan.githubuser.data.local.entities.FavoriteUserEntity
import com.salugan.githubuser.data.local.room.FavoriteUserDao
import com.salugan.githubuser.data.remote.model.User
import com.salugan.githubuser.data.remote.model.responses.DetailUserResponse
import com.salugan.githubuser.data.remote.model.responses.SearchResponse
import com.salugan.githubuser.data.remote.retrofit.ApiService

class UserRepository private constructor(
    private val apiService: ApiService,
    private val favoriteUserDao: FavoriteUserDao,
    ) {

    fun findUser(username: String): LiveData<Result<List<User>>> = liveData {
        emit(Result.Loading)
        try {
            val response: SearchResponse = apiService.getListUsers(username)
            val users: List<User> = response.users ?: emptyList()
            emit(Result.Success(users))
        } catch (e: Exception) {
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getDetailUser(username: String): LiveData<Result<DetailUserResponse>> = liveData {
        emit(Result.Loading)
        try {
            val response: DetailUserResponse = apiService.getDetailUser(username)
            val user: DetailUserResponse = response
            emit(Result.Success(user))
        } catch (e: Exception) {
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getFollowers(username: String): LiveData<Result<List<User>>> = liveData {
        emit(Result.Loading)
        try {
            val followers: List<User> = apiService.getFollowers(username)
            emit(Result.Success(followers))
        } catch (e: Exception) {
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getFollowing(username: String): LiveData<Result<List<User>>> = liveData {
        emit(Result.Loading)
        try {
            val followers: List<User> = apiService.getFollowing(username)
            emit(Result.Success(followers))
        } catch (e: Exception) {
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getFavoriteUsers(): LiveData<List<FavoriteUserEntity>> {
        return favoriteUserDao.getFavoriteUsers()
    }

    fun getFavoriteUserByUsername(username: String): LiveData<FavoriteUserEntity> {
        Log.d("teserak", "ini adalah $username")
        return favoriteUserDao.getFavoriteUserByUsername(username)
    }

    suspend fun addFavoriteUser(user: FavoriteUserEntity) {
        favoriteUserDao.insert(user)
    }

    suspend fun deleteFavoriteUser(user: FavoriteUserEntity) {
        favoriteUserDao.delete(user)
    }

    companion object {
        @Volatile
        private var instance: UserRepository? = null
        fun getInstance(
            apiService: ApiService,
            favoriteUserDao: FavoriteUserDao,
        ): UserRepository =
            instance ?: synchronized(this) {
                instance ?: UserRepository(apiService, favoriteUserDao)
            }.also { instance = it }
    }
}