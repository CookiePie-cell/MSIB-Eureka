package com.salugan.githubuser.ui.activities.favorite

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.ViewModel
import com.salugan.githubuser.data.UserRepository
import com.salugan.githubuser.data.local.entities.FavoriteUserEntity

class FavoriteViewModel(private val userRepository: UserRepository) : ViewModel() {
    private val favoriteUser = MediatorLiveData<List<FavoriteUserEntity>>()

    init {
        getFavoriteUsers()
    }

    fun getFavoriteUsers(): LiveData<List<FavoriteUserEntity>> {
        val users = userRepository.getFavoriteUsers()
        favoriteUser.addSource(users) { result ->
            favoriteUser.value = result
        }
        return favoriteUser
    }
}