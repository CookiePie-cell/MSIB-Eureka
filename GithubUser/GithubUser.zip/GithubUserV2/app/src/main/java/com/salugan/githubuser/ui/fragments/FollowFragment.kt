package com.salugan.githubuser.ui.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.salugan.githubuser.R
import com.salugan.githubuser.adapters.ListUserAdapter
import com.salugan.githubuser.data.remote.model.User
import com.salugan.githubuser.databinding.FragmentFollowBinding
import com.salugan.githubuser.ui.ViewModelFactory
import com.salugan.githubuser.data.Result

class FollowFragment : Fragment() {

    private var _binding: FragmentFollowBinding? = null
    private val binding get() = _binding!!

    private val followViewModel by viewModels<FollowViewModel> {
        ViewModelFactory.getInstance(requireActivity())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFollowBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val position = arguments?.getInt(ARG_POSITION)
        val username = arguments?.getString(ARG_USERNAME)

        val layoutManager = LinearLayoutManager(requireActivity())
        binding.rvFollow.layoutManager = layoutManager
        if (position == 1) {
            if (username != null) {
                followViewModel.getFollowers(username).observe(viewLifecycleOwner) { result ->
                    when (result) {
                        is Result.Loading -> {
                            showLoading(true)
                        }
                        is Result.Success -> {
                            showLoading(false)
                            val followers = result.data
                            checkVisibility(followers)
                        }
                        is Result.Error -> {
                            showLoading(false)
                            binding.followStatus.visibility = View.VISIBLE
                            binding.followStatus.text = result.error
                        }
                    }
                }
            }
        } else {
            if (username != null) {
                followViewModel.getFollowing(username).observe(viewLifecycleOwner) { result ->
                    when (result) {
                        is Result.Loading -> {
                            showLoading(true)
                        }
                        is Result.Success -> {
                            showLoading(false)
                            val followings = result.data
                            checkVisibility(followings)
                        }
                        is Result.Error -> {
                            showLoading(false)
                            binding.followStatus.visibility = View.VISIBLE
                            binding.followStatus.text = result.error
                        }
                    }
                }
            }
        }
    }

    private fun checkVisibility(users: List<User>) {
        if (users.isEmpty()) {
            binding.rvFollow.visibility = View.GONE
            binding.followStatus.visibility = View.VISIBLE
            binding.followStatus.text = getString(R.string.no_data)
        } else {
            binding.rvFollow.visibility = View.VISIBLE
            binding.followStatus.visibility = View.GONE
            setRecyclerViews(users)
        }
    }

    private fun setRecyclerViews(users: List<User>) {
        val listUsers = ArrayList<User>()
        for (user in users) {
            listUsers.add(user)
        }
        val adapter = ListUserAdapter(listUsers)
        Log.d("testing12", adapter.itemCount.toString())
        binding.rvFollow.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar2.visibility = View.VISIBLE
        } else {
            binding.progressBar2.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    companion object {
        const val ARG_POSITION = "position"
        const val ARG_USERNAME = "username"
    }
}