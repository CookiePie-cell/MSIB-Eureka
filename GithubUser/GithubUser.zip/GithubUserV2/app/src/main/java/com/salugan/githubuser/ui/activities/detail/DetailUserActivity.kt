package com.salugan.githubuser.ui.activities.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.salugan.githubuser.R
import com.salugan.githubuser.adapters.SectionsPagerAdapter
import com.salugan.githubuser.data.remote.model.responses.DetailUserResponse
import com.salugan.githubuser.databinding.ActivityDetailUserBinding
import com.salugan.githubuser.data.Result
import com.salugan.githubuser.data.local.entities.FavoriteUserEntity
import com.salugan.githubuser.ui.ViewModelFactory

class DetailUserActivity : AppCompatActivity() {

    private lateinit var activityDetailUserBinding: ActivityDetailUserBinding
    private val detailViewModel by viewModels<DetailViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private var isFavorite = false

    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
        const val EXTRA_USERNAME = "extra_username"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityDetailUserBinding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(activityDetailUserBinding.root)

        supportActionBar?.title = "Detail"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val username = intent.getStringExtra(EXTRA_USERNAME)

        if (username != null) {
            detailViewModel.getDetailUser(username).observe(this) { result ->
                when (result) {
                    is Result.Loading -> {
                        showLoading(true)
                    }
                    is Result.Success -> {
                        showLoading(false)
                        setDetailView(result.data)
                    }
                    is Result.Error -> {
                        showLoading(false)
                        Snackbar.make(
                            window.decorView.rootView,
                            result.error,
                            Snackbar.LENGTH_INDEFINITE
                        ).show()
                    }
                }
            }
        }

        detailViewModel.getFavoriteUserByUsername(username!!).observe(this) { user ->
            Log.d("teserak", (user == null).toString())
            Log.d("teserak", username)
            isFavorite = user != null
            if (isFavorite) activityDetailUserBinding.fab.setImageResource(R.drawable.favorite_full_24)
            else activityDetailUserBinding.fab.setImageResource(R.drawable.favorite_border_24)
        }

        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        sectionsPagerAdapter.username = username
        val viewPager: ViewPager2 = activityDetailUserBinding.viewPager
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = activityDetailUserBinding.tabs
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

    }

    private fun setDetailView(detailUser: DetailUserResponse) {
        activityDetailUserBinding.userDetailInfo.detailUsername.text = detailUser.login
        activityDetailUserBinding.userDetailInfo.detailName.text = detailUser.name
        activityDetailUserBinding.userDetailInfo.followInfo.followers.text = detailUser.followers.toString()
        activityDetailUserBinding.userDetailInfo.followInfo.following.text = detailUser.following.toString()
        Glide.with(this@DetailUserActivity)
            .load(detailUser.avatarUrl)
            .into(activityDetailUserBinding.userDetailInfo.userAvatar)
        activityDetailUserBinding.fab.setOnClickListener {
            val favoriteUser = FavoriteUserEntity(detailUser.login!!, detailUser.avatarUrl)
            if (!isFavorite) {
                detailViewModel.addFavoriteUser(favoriteUser)
                Toast.makeText(this, "Added to favorite", Toast.LENGTH_SHORT).show()
            }
            else {
                detailViewModel.deleteFavoriteUser(favoriteUser)
                Toast.makeText(this, "Removed from favorite", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            activityDetailUserBinding.progressBar.visibility = View.VISIBLE
        } else {
            activityDetailUserBinding.progressBar.visibility = View.GONE
        }
    }
}