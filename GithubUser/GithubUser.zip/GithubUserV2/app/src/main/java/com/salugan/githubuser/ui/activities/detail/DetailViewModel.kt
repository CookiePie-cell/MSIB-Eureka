package com.salugan.githubuser.ui.activities.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.salugan.githubuser.data.Result
import com.salugan.githubuser.data.UserRepository
import com.salugan.githubuser.data.local.entities.FavoriteUserEntity
import com.salugan.githubuser.data.remote.model.responses.DetailUserResponse
import kotlinx.coroutines.launch

class DetailViewModel(private val userRepository: UserRepository) : ViewModel() {
    private val detailUserResult = MediatorLiveData<Result<DetailUserResponse>>()

    private var username: String? = null

    fun getDetailUser(username: String): LiveData<Result<DetailUserResponse>> {

        if (this.username == null) {
            this.username = username
            val source = userRepository.getDetailUser(username)
            detailUserResult.addSource(source) { result ->
                detailUserResult.value = result
            }
        }
        return detailUserResult
    }

    fun getFavoriteUserByUsername(username: String): LiveData<FavoriteUserEntity> {
        return userRepository.getFavoriteUserByUsername(username)
    }

    fun addFavoriteUser(user: FavoriteUserEntity) {
        viewModelScope.launch {
            userRepository.addFavoriteUser(user)
        }
    }

    fun deleteFavoriteUser(user: FavoriteUserEntity) {
        viewModelScope.launch {
            userRepository.deleteFavoriteUser(user)
        }
    }
}